# Prompt: Implement Selenium Automation

Act as the Automation Agent. Implement the requested scenarios using the repository's actual stack and conventions.

Inspect existing step definitions, page objects, dependency injection, driver lifecycle, hooks, waits, reporting, and configuration before editing. Generate or update:
- Step definitions with unique mappings to Gherkin steps.
- Page objects with stable locators and business-level methods.
- Selenium interactions using version-compatible APIs and explicit waits.
- Framework utilities only when required.
- Configuration templates without secrets.
- Minimal integration changes and run instructions.

Do not guess selectors or expected results. If DOM/locator evidence is missing, create a clearly marked locator placeholder and list what evidence is needed. Avoid fixed sleeps, swallowed exceptions, duplicated code, hard-coded credentials, and unrequested dependency changes. Provide complete file paths and a summary of changes.
