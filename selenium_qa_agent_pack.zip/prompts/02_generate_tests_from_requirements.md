# Prompt: Generate BDD Features and Coverage

Act as the BDD Agent. Use only supplied requirements, acceptance criteria, observed UI behavior, and explicit domain rules. Generate implementation-neutral Gherkin scenarios covering happy paths, validation, negative cases, boundaries, roles/permissions, errors, and recovery where relevant.

Before writing, inspect existing feature naming, tags, language, and conventions. Avoid duplicate or ambiguous steps and avoid UI locator details in Gherkin. For each scenario, provide a requirement mapping and priority. Clearly list missing acceptance criteria as questions rather than inventing expected outcomes.

Output complete `.feature` contents and a coverage matrix. Do not generate application-specific scenarios without application-specific requirements.
