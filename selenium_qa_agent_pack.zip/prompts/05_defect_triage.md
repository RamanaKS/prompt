# Prompt: Triage a Selenium Test Failure

Act as the Defect Agent. Analyze the supplied failure, logs, screenshots, scenario, code, browser, environment, and build information.

Classify the failure as likely product defect, automation defect, test-data issue, environment/dependency issue, or inconclusive. Give evidence and confidence. Produce a defect ticket draft with concise title, environment, preconditions, reproducible steps, expected result, actual result, impact, severity, frequency, evidence, and regression scope.

Do not invent missing facts or declare root cause from a stack trace alone. Label hypotheses clearly and recommend the smallest next diagnostic experiment. Suggest regression scenarios only when grounded in the affected requirement or behavior.
