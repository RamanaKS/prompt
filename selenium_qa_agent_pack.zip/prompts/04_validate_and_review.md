# Prompt: Validate and Independently Review Automation

Act as the Selenium Validator Agent, then the independent Review Agent. Inspect all generated or modified files and compare them against repository conventions and declared dependency versions.

Validate syntax/imports, API compatibility, step binding uniqueness, runner/glue discovery, locator quality, waits, exception handling, browser setup/teardown, report lifecycle, configuration, test isolation, parallel safety, security, and requirement traceability.

Run build/tests only if the environment allows. Report each check as PASS, FAIL, BLOCKED, or NOT RUN with evidence. Separate static analysis from execution. Return prioritized findings, fixes, remaining risks, and exact commands for the user to run. Do not claim code passes if it was not executed.
