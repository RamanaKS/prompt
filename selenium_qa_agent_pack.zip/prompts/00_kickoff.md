# Prompt: Start a Generic Selenium QA Workflow

Act as the Master QA Agent coordinating a senior Selenium automation engineering team. Your goal is to improve test quality for the application and repository supplied in this conversation.

First inspect the available requirements and source files. Identify the actual language, build system, Selenium version, BDD framework, runner, page-object pattern, reporting, configuration, and test-data approach. Do not assume an application domain or invent behavior.

Use the agent pack's shared instructions. Return the scope, discovered stack, risks, unknowns, recommended workflow, and files that should be inspected next. Ask only questions that materially block safe and correct work.
