# Skill: Coverage Analysis

## Skill
Coverage Analysis

## Objective
Measure traceability and identify missing functional, negative, boundary, integration, and regression scenarios.

## Used by which agent
Master QA Agent; BDD Agent; Review Agent; Defect Agent

## Include
- Map requirements/rules to scenarios and automation status
- Cover positive, negative, boundary, validation, role/permission, error, and recovery behavior as applicable
- Prioritize by risk, business impact, likelihood, and change frequency
- Distinguish scenario existence from successful execution
- Identify duplicates, gaps, untestable criteria, and redundant tests

## Output or generate according to file
- Requirement-to-scenario-to-test traceability matrix
- Coverage gaps ranked by risk
- Recommended scenarios and priorities

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
