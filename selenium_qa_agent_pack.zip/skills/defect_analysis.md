# Skill: Defect Analysis

## Skill
Defect Analysis

## Objective
Classify test failures, investigate likely causes, and produce reproducible defect reports grounded in evidence.

## Used by which agent
Defect Agent; Master QA Agent; Selenium Validator Agent

## Include
- Gather reproduction steps, expected/actual result, logs, screenshots, environment, browser, and build details
- Separate product, automation, data, environment, and dependency failures
- Assess reproducibility and impact
- Label hypotheses and confidence; do not invent root cause
- Recommend targeted diagnostic checks and regression scope

## Output or generate according to file
- Defect ticket draft
- Failure classification, severity, confidence, and evidence
- Next steps and suggested regression tests

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
