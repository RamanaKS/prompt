# Skill: Selenium Code Generation

## Skill
Selenium Code Generation

## Objective
Produce reliable Selenium WebDriver code compatible with the repository's language and Selenium version.

## Used by which agent
Automation Agent; Selenium Validator Agent

## Include
- Use APIs compatible with declared dependencies
- Apply explicit waits and clear timeout handling
- Handle windows, frames, alerts, dropdowns, uploads, and dynamic elements only as required
- Make interactions deterministic and failures diagnosable
- Avoid hard-coded credentials, brittle selectors, Thread.sleep, and swallowed exceptions
- Preserve project conventions and browser lifecycle

## Output or generate according to file
- Selenium methods or test code
- Supporting imports/configuration
- Reliability notes and execution prerequisites

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
