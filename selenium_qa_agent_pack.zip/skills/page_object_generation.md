# Skill: Page Object Generation

## Skill
Page Object Generation

## Objective
Generate page/component abstractions that encapsulate locators and browser interactions behind reusable, readable methods.

## Used by which agent
Automation Agent; Selenium Validator Agent

## Include
- Inspect current POM conventions and WebDriver ownership
- Prefer stable IDs, data-testid, accessible attributes, and robust CSS; use XPath only when justified
- Use explicit waits for visibility/clickability/state
- Expose business-level actions and state queries
- Keep test-specific assertions and scenario orchestration outside page objects
- Avoid duplicated locators, brittle indexes, sleeps, and hidden global state

## Output or generate according to file
- Page/component classes
- Locator strategy notes and assumptions
- Required step-definition integration changes

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
