# Skill: Step Definition Generation

## Skill
Step Definition Generation

## Objective
Create glue code that binds Gherkin steps to reusable automation actions without duplicating behavior.

## Used by which agent
Automation Agent; Master QA Agent

## Include
- Discover language, Cucumber version, glue packages, DI mechanism, and naming style
- Match step expressions uniquely and avoid ambiguous/duplicate bindings
- Parse DataTables, doc strings, and Scenario Outline parameters safely
- Delegate UI actions to page objects
- Keep assertions and meaningful failure messages at the appropriate test layer
- Reuse shared context only through the project's supported dependency injection

## Output or generate according to file
- Step-definition source files in the repository's language
- Step-to-page-method mapping
- Missing bindings and dependency notes

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
