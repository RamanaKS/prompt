# Skill: Code Validation

## Skill
Code Validation

## Objective
Systematically check generated or existing automation code for correctness, compatibility, reliability, and maintainability.

## Used by which agent
Selenium Validator Agent; Review Agent; Master QA Agent

## Include
- Static inspection of syntax, imports, APIs, naming, selectors, waits, exceptions, and resource cleanup
- Validate runner and feature/glue discovery
- Check dependency versions and config property names
- Detect flaky timing, test coupling, parallel safety risks, and secret leakage
- Execute build/tests only if available and record evidence
- Mark every check PASS/FAIL/BLOCKED/NOT RUN

## Output or generate according to file
- Validation report with severity and evidence
- Build/test command output summary when executed
- Fix recommendations and unresolved checks

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
