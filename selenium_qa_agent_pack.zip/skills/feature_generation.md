# Skill: Feature Generation

## Skill
Feature Generation

## Objective
Turn requirements, user stories, and acceptance criteria into concise Gherkin features and scenarios.

## Used by which agent
BDD Agent; Master QA Agent

## Include
- Requirement/acceptance-criteria extraction
- Happy path, negative, boundary, permissions, and error scenarios
- Scenario Outline/Examples where data variation is meaningful
- Tags and Background only when they improve organization
- Requirement-to-scenario traceability
- Ambiguity and missing-rule reporting

## Output or generate according to file
- `.feature` content grouped by feature
- Scenario coverage matrix
- Open questions and assumptions

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
