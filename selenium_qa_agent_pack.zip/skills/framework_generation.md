# Skill: Framework Generation

## Skill
Framework Generation

## Objective
Create or extend a scalable test automation framework with clear separation of concerns and repeatable execution.

## Used by which agent
Automation Agent; Master QA Agent; Review Agent

## Include
- Inspect Maven/Gradle/build system, runner, dependencies, configuration, logging, reporting, hooks, driver factory, test data, and CI setup
- Design lifecycle and dependency injection
- Support environment configuration without secrets in source
- Consider parallel execution only when driver, pages, test data, and reporting are thread-safe
- Include failure screenshots/logging and deterministic cleanup
- Avoid unnecessary dependencies and architecture changes

## Output or generate according to file
- Framework source/config files
- Folder structure and architecture explanation
- Run commands and configuration template
- Migration notes and limitations

## Quality gate
The output must follow the target repository's actual stack and conventions. Unknown application behavior, selectors, expected results, and configuration must be asked about or explicitly marked as assumptions—not fabricated.
