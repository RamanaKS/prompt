# Generic Selenium QA Multi-Agent Pack

This pack defines reusable agents, skills, global instructions, and prompts for Selenium-based automation projects. It is **not tied to Edureka or any particular application**.

## Contents
- `agents/`: Master QA, BDD, Automation, Selenium Validator, Review, and Defect agents.
- `skills/`: feature generation, step-definition generation, Page Object generation, Selenium code generation, framework generation, code validation, coverage analysis, and defect analysis.
- `instructions/MASTER_INSTRUCTIONS.md`: shared operating rules, safety constraints, workflow, and quality gates.
- `prompts/`: reusable kickoff, repository analysis, feature generation, implementation, validation, review, and defect-triage prompts.
- `ANALYSIS.md`: static review of the uploaded source archive and tailored improvement opportunities.

## How to use
1. Give the agents and skills to the agent platform you use, adapting only its required frontmatter/schema.
2. Start with `prompts/01_repository_analysis.md` to inventory the target repository.
3. Use `prompts/02_generate_tests_from_requirements.md` to create BDD coverage.
4. Use `prompts/03_implement_automation.md` to generate step definitions, page objects, and framework code.
5. Run `prompts/04_validate_and_review.md` before accepting generated changes.
6. Use `prompts/05_defect_triage.md` for failed tests and reproducible defects.

## Compatibility note
The files use plain Markdown so they can be adapted to different agent frameworks. They are specifications/prompts, not executable agent definitions for a specific vendor. Convert the headings/frontmatter to your platform's schema if required.

## Core quality rules
- Discover the repository's actual stack and conventions before writing code.
- Never invent application selectors, APIs, expected outcomes, or requirements. Mark unknowns as questions or assumptions.
- Prefer stable locators, explicit waits, accessible semantics, and Page Object Model separation.
- Do not hard-code secrets or real user data.
- Do not claim code compiles or tests pass unless execution evidence exists.
